package com.example.click.me;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeApplicationTests {

	@Test
	void contextLoads() {
	}

}
